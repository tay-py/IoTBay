/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.model.dao;
import IoTBay.mvp.model.Staff;
import IoTBay.mvp.model.Admin;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author misel
 */
public class DBManager {

    private Statement st;

    public DBManager(Connection conn) throws SQLException {       
       st = conn.createStatement();   
    }

    //Find staff by email and password in the database   
    public Staff findStaff(String username) throws SQLException {       
       //setup the select sql query string       
       //execute this query using the statement field       
       //add the results to a ResultSet       
       //search the ResultSet for a staff using the parameters 
       String fetch = "select * from MICHELLE.STAFFS WHERE STAFFUSERNAME = '" + username + "'";
       ResultSet rs = st.executeQuery(fetch);
       
       while(rs.next()){
           String staff_username = rs.getString(6);
           String staff_password = rs.getString(7);
           if(staff_username.equals(username)){
                String staff_first_name = rs.getString(2);
                String staff_email = rs.getString(4);
                String staff_address = rs.getString(5);
                String staff_last_name = rs.getString(3);
                String staff_position = rs.getString(8);
                Boolean staff_active = rs.getBoolean(9);
                return new Staff(staff_first_name, staff_last_name, staff_email, staff_address, staff_username, staff_password, staff_position,staff_active);
           }
       }
       
       return null;   
    }
    
    
    //Find staff by email and password in the database   
    public Staff searchStaff(String username, String position) throws SQLException {       
       //setup the select sql query string       
       //execute this query using the statement field       
       //add the results to a ResultSet       
       //search the ResultSet for a staff using the parameters 
       String fetch = "select * from MICHELLE.STAFFS WHERE STAFFUSERNAME = '" + username + "' AND STAFFPOSITION ='" + position +"'";
       ResultSet rs = st.executeQuery(fetch);
       
       while(rs.next()){
           String staff_username = rs.getString(6);
           String staff_position = rs.getString(8);
           if(staff_username.equals(username) || staff_position.equals(position)){
                String staff_password = rs.getString(7);
                String staff_first_name = rs.getString(2);
                String staff_email = rs.getString(4);
                String staff_address = rs.getString(5);
                String staff_last_name = rs.getString(3);
                Boolean staff_active = rs.getBoolean(9);
                return new Staff(staff_first_name, staff_last_name, staff_email, staff_address, staff_username, staff_password, staff_position, staff_active);
           }
       }
       
       return null;   
    }
    
    //Find admin by email and password in the database   
    public Admin findAdmin(String username, String password) throws SQLException {       
       //setup the select sql query string       
       //execute this query using the statement field       
       //add the results to a ResultSet       
       //search the ResultSet for a admin using the parameters 
       String fetch = "select * from MICHELLE.ADMINS WHERE ADMINUSERNAME = '" + username + "' AND ADMINPASSWORD = '" + password + "'";
       ResultSet rs = st.executeQuery(fetch);
       
       while(rs.next()){
           String admin_username = rs.getString(1);
           String admin_password = rs.getString(2);
           if(admin_username.equals(username) && admin_password.equals(password)){
                return new Admin(admin_username, admin_password);
           }
       }
       return null;   
    }

    //Add a staff-data into the database   
    public void addStaff(String firstName, String lastName, String email, String address, String username, String password, String position) throws SQLException {                   //code for add-operation       
      st.executeUpdate(
        "INSERT INTO MICHELLE.STAFFS " + "VALUES (DEFAULT, '" + firstName + "','" +
         lastName + "','" + email + "','" + address + "','" + username + "','" +
         password + "','" + position + "', TRUE )");   
    }

    //update a staff details in the database   
    public void updateStaff(String firstName, String lastName, String email, String address, String username, String password, String position, String oldUsername, Boolean active) throws SQLException {       
        st.executeUpdate(
         "UPDATE MICHELLE.STAFFS " + "SET STAFFFNAME='" + firstName + "', STAFFLNAME ='" +
         lastName + "', STAFFEMAIL ='" + email + "', STAFFADDRESS ='" + address + "', STAFFUSERNAME ='" 
         + username + "', STAFFPASSWORD ='" + password +  "', STAFFPOSITION='" + position + "', STAFFACTIVE= " + active + " WHERE STAFFUSERNAME='" + oldUsername + "'");    
    }       

    //delete a staff from the database   
    public void deleteStaff(String username) throws SQLException{       
        st.executeUpdate("DELETE FROM MICHELLE.STAFFS WHERE STAFFUSERNAME ='" + username +  "'");
            }

    // fetch staffs
    public ArrayList<Staff> fetchStaffs() throws SQLException {
        String fetch = "SELECT * from STAFFS";
        ResultSet rs = st.executeQuery(fetch);
        ArrayList<Staff> temp = new ArrayList();

        while(rs.next()){
            String staff_first_name = rs.getString(2);
            String staff_email = rs.getString(4);
            String staff_address = rs.getString(5);
            String staff_username = rs.getString(6);
            String staff_password = rs.getString(7);
            String staff_last_name = rs.getString(3);
            String staff_position = rs.getString(8);
            Boolean staff_active = rs.getBoolean(9);
            temp.add(new Staff(staff_first_name, staff_last_name, staff_email, staff_address, staff_username, staff_password, staff_position, staff_active));
        }
        return temp;
    }
    
    // to verify if staff exist ot no
    public boolean checkStaff(String username, String password) throws SQLException {
        String fetch = "SELECT * from MICHELLE.STAFFS WHERE STAFFUSERNAME = '" + username + "' AND STAFFPASSWORD = '" + password + "'";
        ResultSet rs = st.executeQuery(fetch);
        
        while(rs.next()){
         String staff_username = rs.getString(6);
         String staff_password = rs.getString(7);
         
         if(staff_username.equals(username) && staff_password.equals(password)){
             return true;
           }
        }
     return false;
    }
}
