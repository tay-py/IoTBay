/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.model.controller;


import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import IoTBay.mvp.model.Staff;
import IoTBay.model.dao.DBManager;
import java.util.ArrayList;

/**
 *
 * @author misel
 */
// update the staff details
public class UpdateServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
         String firstName = request.getParameter("firstName");
         String lastName = request.getParameter("lastName");
         String username = request.getParameter("username");
         String password = request.getParameter("password");
         String email = request.getParameter("email");
         String address = request.getParameter("address");
         String position = request.getParameter("position");    
         String oldUsername = request.getParameter("oldUsername");
         Boolean active = Boolean.parseBoolean(request.getParameter("active"));
        
         
         // initialise back to null in case it shows up again
         session.setAttribute("fetchMessage", null);
         session.setAttribute("updated", null);
         session.setAttribute("searchMessage", null);
         session.setAttribute("deleteMessage", null);
         session.setAttribute("searchStaff", null);
         
         Staff staff = new Staff(firstName, lastName, email, address, username, password, position, active);
         DBManager manager = (DBManager) session.getAttribute("manager");
         try{
             if(staff != null){
                 session.setAttribute("staff", staff);
                 manager.updateStaff(firstName, lastName, email, address, username, password, position, oldUsername, active);
                 
                // fetch the UPDATED staff list
                ArrayList<Staff> temp = new ArrayList();
                temp = manager.fetchStaffs();
                if(temp != null){
                    session.setAttribute("staffList", temp);
                } else {
                    session.setAttribute("fetchMessage", "There is no record yet");
                }
                
                 request.getRequestDispatcher("admin_update_staff.jsp").include(request, response);
                 System.out.println("Redirect to admin home portal");
                 response.sendRedirect("admin_home.jsp");
                 
             } else {
                 session.setAttribute("updated", "Update was not successful!" );
                 request.getRequestDispatcher("admin_update_staff.jsp").include(request, response);
             }
         } catch ( SQLException ex){
             Logger.getLogger(EditServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
}
