/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.model.controller;

import IoTBay.model.dao.DBManager;
import IoTBay.mvp.model.Staff;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author misel
 */
// to delete staff 
public class DeleteServlet extends HttpServlet {
    
 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // session 
        HttpSession session = request.getSession();
        String username = request.getParameter("username");
        DBManager manager = ( DBManager) session.getAttribute("manager");
        Staff staff = null;
        
        // initialise back to null
        session.setAttribute("fetchMessage", null);      
        session.setAttribute("deleteMessage", null);
         session.setAttribute("searchMessage", null);
         session.setAttribute("searchStaff", null);         

        try{
            // find the staff in database
            staff = manager.findStaff(username);
            if(staff != null){
                // delete it from database
                manager.deleteStaff(username);
                session.setAttribute("deleteMessage", "Staff is deleted successfully!");

                // fetch the UPDATED staff list
                ArrayList<Staff> temp = new ArrayList();
                temp = manager.fetchStaffs();
                if(temp != null){
                    session.setAttribute("staffList", temp);
                } else {
                    session.setAttribute("fetchMessage", "There is no record yet");
                }

                request.getRequestDispatcher("admin_home.jsp").include(request, response);
            } else {
                session.setAttribute("deleteMessage", "Staff is not deleted!");
                request.getRequestDispatcher("admin_home.jsp").include(request, response);
            }
            System.out.println("Redirect to admin home portal");
            response.sendRedirect("admin_home.jsp");
        } catch (SQLException ex) {
           System.out.println(ex.getErrorCode() + " and " + ex.getMessage());
        }
    }  
}
