/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.controller;

import IoTBay.model.User;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import IoTBay.model.dao.DBManager;


// capture posted data from admin_login.jsp
// validate login credentials using Validator class
public class LoginServlet extends HttpServlet {
    
    @Override   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
            throws ServletException, IOException {       
                
                // Session 
                HttpSession session = request.getSession();
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                
                // Database
                DBManager manager = (DBManager) session.getAttribute("manager");
                User user = null;
                
                // Validator
                Validator validator = new Validator();
                validator.clear(session);
                
                // initialise back to null
                session.setAttribute("usernameErr", null);
                session.setAttribute("passErr", null);
                session.setAttribute("existErr", null);

                
                    try {
                        user = manager.findUser(username, password);
                        if (username == null && password == null) {
                            response.sendRedirect("index.jsp");
                        }
                        
                        if(user != null){
                            System.out.println("usernotnull");
                            session.setAttribute("user", user);        
                            session.setAttribute("username", username);      
                            session.setAttribute("password", password); 
                            //session.setAttribute("userId", userId); 
                            System.out.println(username);
                            System.out.println(password);
                           // request.getRequestDispatcher("index.jsp").include(request, response);
                           // session.setAttribute("userId", userId);   
                            response.sendRedirect("index.jsp");
                            System.out.println("Redirect to home portal");
                           
                        } else {
                            System.out.println("Redirect to portal");
                            session.setAttribute("existErr", "Error: User does not exist in database");
                            request.getRequestDispatcher("Login.jsp").include(request, response);
                        }
                    } catch (SQLException | NullPointerException ex) {
                        System.out.println(ex.getMessage() == null ? "User does not exist" : "Welcome");
                    }
                }
         }  

