/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.controller;

import IoTBay.model.Payment;
import IoTBay.model.User;
import IoTBay.model.dao.DBManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author desyliunardi
 */
public class InvoiceServlet extends HttpServlet {
    
 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       HttpSession session = request.getSession();
       Integer userId = Integer.parseInt(request.getParameter("userId")); 
       DBManager manager = ( DBManager) session.getAttribute("manager");
       String username = ( String) session.getAttribute("username");
        
       
       //System.out.println(manager.checkRegisUser(userId));
       System.out.println("that");
       if(username != null){
           System.out.println("if");
           //session.setAttribute("fetchMessage", "Payment is deleted successfully!");
           ArrayList<String> temp = new ArrayList();
           try {
               System.out.println(userId);
               temp = manager.fetchPayment(userId);
           } catch (SQLException ex) {
               Logger.getLogger(InvoiceServlet.class.getName()).log(Level.SEVERE, null, ex);
           }
                            if(temp != null){
                                session.setAttribute("paymentList", temp);
                            }  else {
                                session.setAttribute("fetchMessage", "There is no record yet");
                            }
           //request.getRequestDispatcher("UserViewHistory.jsp").include(request, response);
           response.sendRedirect("UserViewHistory.jsp");
           
       } else {
           System.out.println("else");
           session.setAttribute("fetchMessage", "Payment is not deleted!");
           request.getRequestDispatcher("AnonViewHistory.jsp").include(request, response);
       }
//            System.out.println("Redirect to admin home portal");
//            response.sendRedirect("OrderCart.jsp");
    }  
}
