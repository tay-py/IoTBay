/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.controller;

import IoTBay.model.Order;
import IoTBay.model.Payment;
import IoTBay.model.User;
import IoTBay.model.dao.DBManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author desyliunardi
 */
public class CreateOrderServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Session
         HttpSession session = request.getSession();
         Double amount = Double.parseDouble(request.getParameter("amount"));
         //Integer userId = Integer.parseInt(request.getParameter("userId"));
         String username =request.getParameter("username");
         String password =request.getParameter("password");
         
         Order order = new Order( amount );
         //User userId = (User)session.getAttribute("userId");
         DBManager manager = (DBManager) session.getAttribute("manager");
         //session.setAttribute("userId", userId);
        
         try {
             if(order != null){
                 session.setAttribute("order", order);
                 System.out.println(username);
                 System.out.println(password);
                 Integer userId = manager.getUserId(username, password);                 
                 session.setAttribute("userId", userId);
                 System.out.println(userId);
                 System.out.println("id");
                 System.out.println(userId);
                 manager.addOrder(amount, userId);
                 Integer orderId = manager.getOrderId();
                 session.setAttribute("orderId", orderId);
                 request.getRequestDispatcher("OrderCart.jsp").include(request, response);
                 System.out.println("Redirect to HomePage");
                 response.sendRedirect("OrderCart.jsp");
             } else {
                 session.setAttribute("Not Created", "Creating Payment is not successful!" );
                 request.getRequestDispatcher("Home.jsp").include(request, response);
             }
             
         } catch ( SQLException ex){
             //Logger.getLogger(EditServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
}