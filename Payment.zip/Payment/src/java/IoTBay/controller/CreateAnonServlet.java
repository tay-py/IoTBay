/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.controller;

import IoTBay.model.User;
import IoTBay.model.dao.DBManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author desyliunardi
 */
public class CreateAnonServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Session
         HttpSession session = request.getSession();
         String username = request.getParameter("username");
         String password = request.getParameter("password");
         Integer userId = Integer.parseInt(request.getParameter("userId"));
         
         User user = new User( username, password );
         DBManager manager = (DBManager) session.getAttribute("manager");
         //DBManager userId = (DBManager) session.getAttribute("userId");
         if(user == null){
             session.setAttribute("user", user);
             // manager.addUser(username, password);
             //Integer userId = manager.getUserId();
             session.setAttribute("userId", userId);
             request.getRequestDispatcher("index.jsp").include(request, response);
             System.out.println("Redirect to HomePage");
             response.sendRedirect("index.jsp");
         } else {
             session.setAttribute("Not Created", "Creating Payment is not successful!" );
             request.getRequestDispatcher("index.jsp").include(request, response);
         }
    }
}