/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IoTBay.model.dao;

import java.sql.*;
import java.util.ArrayList;
import IoTBay.model.Payment;
import IoTBay.model.User;


/**
 *
 * @author desyliunardi
 */


public class DBManager {
    
    private final Statement st;

    
    public DBManager(Connection conn) throws SQLException {
        st = conn.createStatement();
    }
    
    
    public int getPaymentId() throws SQLException {
       int paymentId;
       // int order_Id = orderId;
       String fetch = "select MAX(PAYMENTID) FROM IOTBAY.PAYMENT" ;
       ResultSet rs = st.executeQuery(fetch);
       if (rs.next()) {
            paymentId = rs.getInt(1);
            return paymentId;
       } else {
           return 0;
       }
    }
    
  
     public Payment foundedPaymentId(Integer paymentId) throws SQLException {       
       String fetch = "select * from IOTBAY.PAYMENT WHERE PAYMENTID = "+paymentId+" ";
       ResultSet rs = st.executeQuery(fetch);
       
       while(rs.next()){
           Integer payment_Id = rs.getInt(1);
           if(payment_Id.equals(paymentId)){
                String paymentMethod  = rs.getString(3);
                Integer cardNumber = rs.getInt(4);
                Integer cvv = rs.getInt(5);
                String nameOnCard = rs.getString(6);
                String expiryDate = rs.getString(7);
                String datePaid = rs.getString(8);
                return new Payment(paymentMethod, cardNumber, cvv, nameOnCard, expiryDate, datePaid );
                }
           }
       return null;   
    }
     
    
     //Search paymnet by ID and date in the database - Read one row in the database table
    public Payment searchPayment(Integer paymentId, String datePaid) throws SQLException {       
       String fetch = "select * from IOTBAY.PAYMENT WHERE PAYMENTID= "+paymentId+" and DATEPAID ='" + datePaid +"' ";
       ResultSet rs = st.executeQuery(fetch);
       
       while(rs.next()){
           Integer payment_Id = rs.getInt(1);
           String date_Paid = rs.getString(8);
           if(payment_Id.equals(paymentId) && date_Paid.equals(datePaid)){
                Integer orderId = rs.getInt(2);
                String paymentMethod  = rs.getString(3);
                Integer cvv = rs.getInt(5);
                String expiryDate = rs.getString(7);
                Integer cardNumber = rs.getInt(4);
                String nameOnCard = rs.getString(6);
                return new Payment( paymentMethod, cardNumber, cvv, nameOnCard, expiryDate, datePaid );
                }
           }
       return null;   
    }
    
    
    //Add a student-data into the database
    public void addPayment( Integer OrderId, String paymentMethod, Integer cardNumber, Integer cvv, String nameOnCard, String expiryDate, String datePaid) throws SQLException {
        st.executeUpdate("INSERT INTO IOTBAY.PAYMENT " + "VALUES (DEFAULT , " + OrderId + ",'" + paymentMethod + "', " + cardNumber + ", " + cvv + ",'" + nameOnCard + "', '" + expiryDate + "', '" + datePaid + "') ");
    }
    
    
    //Update a student details in the database 
    public void updatePayment(Integer paymentId, String paymentMethod, Integer cardNumber,
            Integer cvv, String nameOnCard, String expiryDate, String datePaid) throws SQLException {
        st.executeUpdate("UPDATE IOTBAY.PAYMENT SET paymentMethod='" + paymentMethod + "', cardNumber=" + 
                cardNumber + ", cvv =" + cvv + ",  nameOnCard='" + nameOnCard + "', expiryDate='" + 
                expiryDate + "',  datePaid='" + datePaid + "' WHERE paymentId = " + paymentId +" ");
    }
    
    
    //delete a student from database
    public void deletePayment (Integer paymentId) throws SQLException {
        st.executeUpdate("DELETE FROM IOTBAY.PAYMENT WHERE paymentId = " + paymentId + " ");
    }

    
    public ArrayList<String> fetchPayment(Integer userId) throws SQLException {
        String fetch = "select * from payment p join iotbayorder o on o.ORDERID = p.ORDERID join iotbayuser u on u.userid = o.USERID where o.USERID = "+userId+"  ";
        ResultSet rs = st.executeQuery(fetch);
        ArrayList<String> temp = new ArrayList();
        
        while(rs.next()) {
            Integer paymentId = rs.getInt(1);
            Integer orderId = rs.getInt(2);
            String paymentMethod  = rs.getString(3);
            Integer cardNumber = rs.getInt(4);
            Integer cvv = rs.getInt(5);
            String nameOnCard = rs.getString(6);
            String expiryDate = rs.getString(7);
            String datePaid = rs.getString(8);
            
            temp.add(Integer.toString(paymentId));
            temp.add(Integer.toString(orderId));
            temp.add(paymentMethod);
            temp.add(Integer.toString(cardNumber));
            temp.add(Integer.toString(cvv));
            temp.add(nameOnCard);
            temp.add(expiryDate);
            temp.add(datePaid);
//temp.add(new Payment( paymentMethod, cardNumber, cvv, nameOnCard, expiryDate, datePaid));
        }
        return temp;
    }

    public boolean checkPayment( Integer paymentId, String datePaid) throws SQLException {
        String fetch = "select * from IOTBAY.PAYMENT WHERE PAYMENTID= "+paymentId+" and DATEPAID ='" + datePaid +"' "; 
        ResultSet rs = st.executeQuery(fetch);
        
        while (rs.next()) {
            Integer payId = rs.getInt(1);
            String date_Paid = rs.getString(9);
            
            if (payId.equals(paymentId) && date_Paid.equals(datePaid)) { 
                return true;
            }
        }
        return false;
    }
    
    
    
    
    
               //////Below here is the function for user and order /////////
    
    

    public User checkRegisUser(Integer userId) throws SQLException {
        String fetch = "select * from iotbayuser where userid = " + userId+" "; 
        ResultSet rs = st.executeQuery(fetch);
        
        while (rs.next()) {
            Integer user_Id = rs.getInt(1);
            if (user_Id.equals(userId)) { 
                String username  = rs.getString(3);
                String password  = rs.getString(2);
                return new User(username, password);
                }
           }
        return null;   
    }
    
    
    ////dummy database
    public int getOrderId() throws SQLException {
       int orderId;
       // int order_Id = orderId;
       String fetch = "select max(ORDERID) FROM IOTBAY.IOTBAYORDER" ;
       ResultSet rs = st.executeQuery(fetch);
       if (rs.next()) {
            orderId = rs.getInt(1);
            return orderId;
       } else {
           return 0;
       }
    }
        
    public void addOrder( Double amount, Integer userId) throws SQLException {
        st.executeUpdate("INSERT INTO IOTBAY.IOTBAYORDER " + "VALUES (DEFAULT ," + amount + ", "+userId+")");
    }
    
    public int getUserId(String username, String password) throws SQLException {
       int userId;
       // int order_Id = orderId;
       String fetch = "select USERID FROM IOTBAY.IOTBAYUSER where username = '"+username+"' and password ='"+password+"' " ;
       ResultSet rs = st.executeQuery(fetch);
       if (!rs.next()) {
           return 1;
       } else {  
            userId = rs.getInt(1);
            return userId;
       }
    } 
    
    public void addUser( String username, String password) throws SQLException {
        st.executeUpdate("INSERT INTO IOTBAY.IOTBAYUSER " + "VALUES (DEFAULT ,'" + password + "', '" + username+"' ) ");
    }
    
     public void deleteUser (Integer userId) throws SQLException {
        st.executeUpdate("DELETE FROM IOTBAY.IOTBAYUSER WHERE userId = " + userId + " ");
    }
     
     
     public User findUser (String username, String password) throws SQLException {
        String fetch = "select * from IOTBAY.IOTBAYUSER where username ='" + username +"' and PASSWORD = '" + password + "'";
        ResultSet rs = st.executeQuery(fetch);
        
        while (rs.next()) {
            String user_name = rs.getString(3);
            String pass_word = rs.getString(2);
            if(user_name.equals(username) && pass_word.equals(password)) {
                return new User(user_name, pass_word);
            }
        }
        return null;
    }
    
     
     
     
}
