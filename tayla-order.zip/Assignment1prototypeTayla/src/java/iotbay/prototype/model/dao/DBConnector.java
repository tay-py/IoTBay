/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iotbay.prototype.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author tayla
 */
public class DBConnector extends DB{
    public DBConnector() throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        conn = DriverManager.getConnection(URL, dbuser, dbpass);
    }
    
    /* 
    BDConnector() constructor uses the JDBC driver
    to build a connection instance (conn) with the database userdb
     */
    
    public Connection openConnection() {
        return this.conn;
    }
    
    /*
    openConnection() returns the conn instance to be used in DBManager
    and execute SQL queries
    */
    
    public void closeConnection() throws SQLException {
        this.conn.close();
    }
    
    /*
    It is important to close the connection with the database
    after executing the queries
    */
}


