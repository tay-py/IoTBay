/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iotbay.prototype.model.dao;

import java.sql.Connection;

/**
 *
 * @author tayla
 */
public abstract class DB {
    protected String URL = "jdbc:derby://localhost:1527/IOTBAY";
    protected String dbuser = "iotbay";
    protected String dbpass = "admin";
    protected String driver = "org.apache.derby.jdbc.ClientDriver";
    protected Connection conn;
}
