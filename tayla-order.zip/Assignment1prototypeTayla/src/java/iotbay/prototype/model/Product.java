/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iotbay.prototype.model;

import java.io.Serializable;

/**
 *
 * @author tayla
 */
public class Product implements Serializable{
    int productID;
    String brand;
    double price;
    int stock;
    boolean availability;
    String description;
    String productName;

    public Product() {
    }

    public Product(int productID, String brand, double price, int stock, boolean availability, String description, String productName) {
        this.productID = productID;
        this.brand = brand;
        this.price = price;
        this.stock = stock;
        this.availability = availability;
        this.description = description;
        this.productName = productName;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    
}
