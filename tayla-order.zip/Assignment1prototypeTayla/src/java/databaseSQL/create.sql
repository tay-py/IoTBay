/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  tayla
 * Created: 26 May 2020
 */

CREATE TABLE USERS 
(
    userID      INT   NOT NULL,
    userUsername    VARCHAR(10),
    userFName   VARCHAR(20),
    userLName   VARCHAR(20),
    userAddress VARCHAR(20),
    userEmail   VARCHAR(40),
    userPassword    VARCHAR(20),
CONSTRAINT USERS_PK PRIMARY KEY (userID)
);


CREATE TABLE ORDERS (
    orderID     INT  NOT NULL ,
    userID      INT,
    orderDate   VARCHAR(10),
    tax         DOUBLE,
    totalPrice  DOUBLE,
    shippingAddress VARCHAR(40),
    billingAddress  VARCHAR(40),
CONSTRAINT ORDER_PK PRIMARY KEY (orderID),
CONSTRAINT ORDER_FK FOREIGN KEY (userID) REFERENCES USERS(userID));

CREATE TABLE PRODUCT
(
    productID     INT  not null  ,
    productName   VARCHAR(20) not null unique,
    brand        VARCHAR(10),
    price       DOUBLE unique,
    stock     INT,
    availability      BOOLEAN,
    description VARCHAR(100),
constraint  PRODUCT_PK    primary key (productID)
);

CREATE TABLE ORDERLINE
(
    orderlineID     INT  not null  ,
    orderID         INT  not null,
    quantity        INT,
    productID       INT,
    productName     VARCHAR(20),
    totalPrice      double,
    price           double,
constraint  ORDERLINE_PK    primary key (orderlineID),
constraint  ORDERLINE_FK1   foreign key (orderID) references orders(orderID),
constraint  ORDERLINE_FK2   foreign key (productName) references product(productName),
constraint  ORDERLINE_FK3   foreign key (productID) references product(productID),
constraint  ORDERLINE_FK4   foreign key (price)     references product(price)
);