/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  tayla
 * Created: 27 May 2020
 */

INSERT INTO IOTBAY.USERS VALUES (1, 'ardepy', 'Tayla', 'Ward', '123 Smith Rd','ardepy@outlook.com','12345');
INSERT INTO IOTBAY.USERS VALUES (2, 'fredo34', 'Fred', 'Roberts', '543 Bolly Rd', 'f.roberts@outlook.com', '12345');
INSERT INTO IOTBAY.USERS VALUES (3, 'dalia90', 'Dalia', 'Huey', '432 Cartwright Ln', 'dalia90@outlook.com','12345');
INSERT INTO IOTBAY.USERS VALUES (4, 'hazza34', 'Harry', 'Ky', '567 Remi St', 'kyh@outlook.com', '12345');

INSERT INTO IOTBAY.PRODUCT VALUES (12345678, 'Dewalt Drill', 'Dewalt', 40.95, 100, true, 'Drill');
INSERT INTO IOTBAY.PRODUCT VALUES (23456789, 'LMC Drill', 'LMC', 90.95, 100, true, 'Drill');