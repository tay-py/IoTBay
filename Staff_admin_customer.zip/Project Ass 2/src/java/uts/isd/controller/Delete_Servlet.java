package uts.isd.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import uts.isd.model.user.*;


@WebServlet(name = "Delete_Servlet", urlPatterns = {"/Delete_Servlet"})
public class Delete_Servlet extends HttpServlet 
{
    private DBConnector Connector;
    private DBManager Query;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String ID = request.getParameter("ID");
        response.setContentType("text/html;charset=UTF-8");
        try
        {
            Connector = new DBConnector();
        }catch (ClassNotFoundException | SQLException ex)
        {
            java.util.logging.Logger.getLogger(Conn_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        try
        {       
        Query = new DBManager(Connector.openConnection());  
        }catch(SQLException ex)
        {
            java.util.logging.Logger.getLogger(Conn_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        try
        {
        Query.deleteUser(ID);
        Connector.closeConnection();
        }
        catch(SQLException ex)
        {
            java.util.logging.Logger.getLogger(Delete_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        response.sendRedirect("index.html");
    }
}
