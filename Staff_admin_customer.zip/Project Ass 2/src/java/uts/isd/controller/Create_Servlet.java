package uts.isd.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import uts.isd.model.user.*;


@WebServlet(name = "Create_Servlet", urlPatterns = {"/Create_Servlet"})
public class Create_Servlet extends HttpServlet 
{
    private DBConnector Connector;
    private DBManager Query;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String USERNAME = request.getParameter("USERNAME");
        String FNAME = request.getParameter("FNAME");
        String LNAME = request.getParameter("LNAME");
        String EMAIL = request.getParameter("EMAIL");
        String PASSWORD = request.getParameter("PASSWORD");
        response.setContentType("text/html;charset=UTF-8");
        try
        {
            Connector = new DBConnector();
            Query = new DBManager(Connector.openConnection());  
        }catch (ClassNotFoundException | SQLException ex)
        {
            java.util.logging.Logger.getLogger(Conn_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        try
        {
        Query.addUser(USERNAME,FNAME,LNAME,EMAIL,PASSWORD);
        Connector.closeConnection();
        }
        catch(SQLException ex)
        {
            java.util.logging.Logger.getLogger(Delete_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        response.sendRedirect("index.html");
    }
}
