/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import uts.isd.model.user.*;

/**
 *
 * @author ASUS
 */
@WebServlet(name = "Conn_Servlet", urlPatterns = {"/Conn_Servlet"})
public class Conn_Servlet extends HttpServlet {

    private DBConnector db;
    private DBManager manager;
    private Connection conn;
    public void init()
    {

    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        try{
            db = new DBConnector();
            response.setContentType("text/html;charset=UTF-8");
            conn = db.openConnection();
             manager = new DBManager(conn);
        }catch (ClassNotFoundException | SQLException ex)
        {
            Logger.getLogger(Conn_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    public void destroy()
        {
            try{
            db.closeConnection();
            }catch (SQLException ex)
            {
                Logger.getLogger(Conn_Servlet.class.getName()).log(Level.SEVERE,null,ex);
            }
        }
}
