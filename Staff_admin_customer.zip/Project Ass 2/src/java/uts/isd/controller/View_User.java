/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import uts.isd.model.user.DBConnector;
import uts.isd.model.user.DBManager;
import java.util.LinkedList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ASUS
 */
@WebServlet(name = "View_User", urlPatterns = {"/View_User"})
public class View_User extends HttpServlet {  
    private DBConnector Connector;
    private DBManager Query;
    private LinkedList list;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        String SEARCH = request.getParameter("SEARCH");
        
        try
        {
            Connector = new DBConnector();
            Query = new DBManager(Connector.openConnection());  
        }catch (ClassNotFoundException | SQLException ex)
        {
            java.util.logging.Logger.getLogger(Conn_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        try
        {
        Query.listCustomer(SEARCH);
        Connector.closeConnection();
        list = Query.get_data();
        session.setAttribute("List", Query.get_data());
        }
        catch(SQLException ex)
        {
            java.util.logging.Logger.getLogger(Delete_Servlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        response.sendRedirect("201-B list_customer.jsp");
    }

}
