package uts.isd.controller;

 

import java.sql.*;

import java.util.*;

import java.util.logging.*;

import uts.isd.model.user.*;

 

public class TestDB {

private static Scanner in = new Scanner(System.in);


public static void main(String[] args) {

try {

DBConnector connector = new DBConnector();

Connection conn = connector.openConnection();

DBManager db = new DBManager(conn);

 

System.out.print("User search: ");

String search = in.nextLine();



db.listCustomer(search);

LinkedList list = db.get_data();

System.out.println(db.get_data().size());
for (int i =0 ; i < list.size(); i++)
{
    System.out.println(list.get(i));
}

   //execute this query using the statement field   



connector.closeConnection();

 

} catch (ClassNotFoundException | SQLException ex) {

Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);

}

}

}