package uts.isd.model.user;
import java.sql.*;
import java.util.*;

/* 
* DBManager is the primary DAO class to interact with the database. 
* Complete the existing methods of this classes to perform CRUD operations with the db.
*/

public class DBManager {

private Statement st;
private LinkedList<String> list_data = new LinkedList<String>(); 
   
public DBManager(Connection conn) throws SQLException 
{       
   st = conn.createStatement();   
}
public LinkedList get_data()
{
    return list_data;
}

public void listCustomer(String Search) throws SQLException {       
    
//setup the select sql query string  
   String query = "SELECT * FROM USERDB WHERE USERFNAME like '%"+Search+"%' OR USERLNAME like '%"+Search+"%' OR USEREMAIL like '%"+Search+"%'";
   //execute this query using the statement field   
   st.executeQuery(query);  
   //add the results to a ResultSet
   ResultSet rs = st.executeQuery(query);
   //search the ResultSet for a user using the parameters
   while(rs.next())
    {
   list_data.add(Integer.toString(rs.getInt("USERID")));
   list_data.add(rs.getString("USERUSERNAME"));
   list_data.add(rs.getString("USERFNAME")); 
   list_data.add(rs.getString("USERLNAME"));
   list_data.add(rs.getString("USEREMAIL"));   
   }
}

public Customer findCustomer(int id, String username) throws SQLException {       
   //setup the select sql query string  
   String query = "SELECT * FROM USERDB WHERE USERID ='"+id+"' AND USERUSERNAME ='"+username+"'";
   //execute this query using the statement field   
   st.executeQuery(query);  
   //add the results to a ResultSet
   ResultSet rs = st.executeQuery(query);
   //search the ResultSet for a user using the parameters
   if(!rs.next())
   {
       return null;
   }
   else
   {
   int UserID = rs.getInt("USERID");
   String Username = rs.getString("USERUSERNAME");
   String UserFirstName = rs.getString("USERFNAME");
   String UserLastName = rs.getString("USERLNAME");
   String UserEmail = rs.getString("USEREMAIL");
   String UserPassword = rs.getString("USERPASSWORD");
   
   Customer current = new Customer(UserID,Username,UserFirstName,UserLastName,UserEmail,UserPassword);
   return current;   
   }
}

//Add a user-data into the database   
public void addUser(String username, String firstname, String lastname, String email, String password) throws SQLException 
{                   //code for add-operation       
    int id = generateID();
    String query = "INSERT INTO USERDB (USERID, USERUSERNAME, USERFNAME, USERLNAME, USEREMAIL, USERPASSWORD) VALUES ('"+id+"','"+username+"','"+firstname+"', '"+lastname+"','"+email+"','"+password+"')";
   //execute this query using the statement field   
   st.executeUpdate(query);  

}

//update a user details in the database   
public void updateUser(String userid, String username, String firstname, String lastname, String email) throws SQLException 
{       
   //setup the select sql query string  
   String query = "UPDATE USERDB SET USERUSERNAME ='"+username+"', USERFNAME='"+firstname+"', USERLNAME='"+lastname+"', USEREMAIL='"+email+"' WHERE USERID='"+userid+"'";
   //execute this query using the statement field   
   st.executeUpdate(query);  

}       

//delete a user from the database   
public void deleteUser(String userid) throws SQLException
{       
   String query = "DELETE FROM USERDB WHERE USERID='"+userid+"'";
   //execute this query using the statement field   
   st.executeUpdate(query);  

}
public int generateID() throws SQLException
{
   String query = "SELECT MAX(USERID) as USERID FROM USERDB";
   //execute this query using the statement field    
   ResultSet rs = st.executeQuery(query);
   //search the ResultSet for a user using the parameters
   if(!rs.next())
   {
       return 1;
   }
   else
   {
   int UserID = rs.getInt("USERID");
   UserID = UserID +1;
   return UserID;  
   }
}
}