/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import uts.isd.model.dao.DBConnector;
import uts.isd.model.dao.DBManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import uts.isd.model.*;

/**
 *
 * @author rebeccagalletta
 */
public class TestDB {
    private static Scanner in = new Scanner(System.in);
    private DBConnector connector;
    private Connection conn;
    private DBManager db; 

    public static void main(String[] args) throws SQLException {
           (new TestDB()).runQueries();
    }
    
    public TestDB(){
        try {
                connector = new DBConnector();
                conn = connector.openConnection();
                db = new DBManager(conn);
        } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private char readChoice(){
        System.out.println("Operation CRUDS or * to exit");
        return in.nextLine().charAt(0);
    }
    
    private void runQueries() throws SQLException {
        char c = readChoice();
        if (c != '*'){
            switch(c){
                case 'C':
                    addNewItem();
                    break;
                case 'R':
                    fetchItem();
                    break;
                case 'U':
                    updateItem();
                    break;
                case 'D':
                    deleteItem();
                    break;
                case 'S':
                    showInventory();
                    break;
                case 'F':
                    fetchProductid();
                    break;
                default:
                    System.out.println("Unknown command");
                    break;
            }
        }
    }
    
    private void addNewItem() {
//        System.out.print("Product ID: ");
//        int productid = in.nextInt();
//        in.nextLine();

        System.out.print("Product Name: ");
        String productname = in.nextLine();

        System.out.print("Brand: ");
        String brand = in.nextLine();

        System.out.print("Price: $");
        double price = in.nextDouble();
        in.nextLine();

        System.out.print("Stock: ");
        int stock = in.nextInt();
        in.nextLine();

//        System.out.print("Availability: ");
//        boolean availability = in.nextBoolean();
//        in.nextLine();

        System.out.print("Description: ");
        String description = in.nextLine();

        try {
            db.addNewItem(productname, brand, price, stock, description);
        }
        catch (SQLException ex){
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Product has been added to the database.");

    }
    
    private void fetchItem() throws SQLException {
        System.out.print("Product Name: ");
        String productname = in.nextLine();
        
        Product product = db.fetchItem(productname);

        if (product != null) {
            System.out.println(product.getProductname() + " exists in the Inventory");
            System.out.println("Product ID: "+ product.getProductid());
            System.out.println("Brand: "+ product.getBrand());
            System.out.println("Price: $"+ product.getPrice());
            System.out.println("Stock: "+ product.getStock());
//            if (product.isAvailability()) {
//                System.out.println("Available: Yes");
//            }
//            else {
//                System.out.println("Available: No");
//            }
            System.out.println("Description: " + product.getDescription());
        }
        else {
            System.out.println("This item does not exist in the Inventory");
        }
    }
    
    /*
    private boolean checkItem(productname) throws SQLException{
        System.out.print("Product Name: ");
        String productname = in.nextLine();
        
        Product product = db.findItemByName(productname);
        
        if(product != null) {
            System.out.println(product.getProductname() + " exists in the Inventory");
            return true;
        } else {
            System.out.println("That product does not exist in the Inventory");
            return false;
        }
    }
    */
    private void updateItem() throws SQLException {
        System.out.print("Product to Update: ");
        String item_productname = in.nextLine();
        
        Product product = db.fetchItem(item_productname);
        
        try {
            if (product != null) {
//                System.out.print("Product ID: ");
//                int productid = in.nextInt();
//                in.nextLine();

                System.out.print("Product Name: ");
                String productname = in.nextLine();

                System.out.print("Brand: ");
                String brand = in.nextLine();

                System.out.print("Price: $");
                double price = in.nextDouble();
                in.nextLine();

                System.out.print("Stock: ");
                int stock = in.nextInt();
                in.nextLine();

//                System.out.print("Availability: ");
//                boolean availability = in.nextBoolean();
//                in.nextLine();

                System.out.print("Description: ");
                String description = in.nextLine();
                

                db.updateItem(product.getProductid(), productname, brand, price, stock, description);
            }
            else {
                System.out.println("Item does not exist in the Inventory");
            }
        } catch (SQLException ex){
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    private void deleteItem() throws SQLException {
        System.out.print("Product Name: ");
        String productname = in.nextLine();
        
        Product product = db.fetchItem(productname);
        try {
            if(product != null) {
                db.deleteItem(productname);
                System.out.println(product.getProductname() + " has been deleted from the Inventory");
            }
            else {
                System.out.println("Product does not exist.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    private void showInventory(){
        try {
            ArrayList<Product> inventory = db.showInventory();
            System.out.println("Inventory List:");
            inventory.stream().forEach((product) -> {
                System.out.printf("%-20s %-30s %-20s %-10s \n", product.getProductid(), product.getProductname(), product.getBrand(), "$"+product.getPrice(), product.getStock(), product.getDescription());
            });
        } catch (SQLException ex) {
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void fetchProductid() {
        System.out.print("Product Name: ");
        String productname = in.nextLine();
        
        try{
            int productid = db.fetchProductid(productname);
            System.out.println("" + productid);
        }
        catch (SQLException ex){
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
          
    }

}
