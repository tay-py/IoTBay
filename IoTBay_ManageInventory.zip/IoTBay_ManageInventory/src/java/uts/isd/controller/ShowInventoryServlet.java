/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import uts.isd.model.dao.DBManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.*;
import uts.isd.model.dao.DBConnector;

/**
 *
 * @author rebeccagalletta
 */
public class ShowInventoryServlet extends HttpServlet {
    
    private DBManager manager;
    private DBConnector Connector;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        try
        {
            Connector = new DBConnector();
        }catch (ClassNotFoundException | SQLException ex){
            java.util.logging.Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        try
        {       
            manager = new DBManager(Connector.openConnection());  
        }catch (SQLException ex){
            java.util.logging.Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        //session
        HttpSession session = request.getSession();
        //String productname = request.getParameter("productname");
        
        //database
        //DBManager manager = (DBManager) session.getAttribute("manager");
        //Product product = null;
        //session.setAttribute("product", null);
        //session.setAttribute("show", null);
        
        try {
            ArrayList<Product> inventory = manager.showInventory();
            if (inventory != null) {
                //Product product = manager.fetchItem(productname);
                //manager.fetchItem(productname);
                session.setAttribute("inventory", inventory);
                request.getRequestDispatcher("showInventory.jsp").include(request, response);
                session.setAttribute("show", "IoTBayInventory");
                response.sendRedirect("showInventory.jsp");
                //System.out.println("Back to Inventory Menu");
                //session.setAttribute("found", "Item has been found in the Inventory");
                //response.sendRedirect("showInventory.jsp");
            }
            else{
                request.getRequestDispatcher("showInventory.jsp").include(request, response);
                session.setAttribute("show", "Inventory does not exist");
                response.sendRedirect("manageInventory.jsp");
            }
            
                            
        } catch (SQLException ex){
            Logger.getLogger(ShowInventoryServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
//        try {
//            Connector.closeConnection();
//        } catch (SQLException ex) {
//            Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }
}
