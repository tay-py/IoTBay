package uts.isd.controller;



import uts.isd.model.dao.DBManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.*;
import uts.isd.model.dao.DBConnector;


public class AddNewItemServlet extends HttpServlet {
    
    private DBManager manager;
    private DBConnector Connector;
    
    @Override //Create and instance of DBConnector for the deployment session
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        try
        {
            Connector = new DBConnector();
        }catch (ClassNotFoundException | SQLException ex){
            java.util.logging.Logger.getLogger(AddNewItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        try
        {       
            manager = new DBManager(Connector.openConnection());  
        }catch (SQLException ex){
            java.util.logging.Logger.getLogger(AddNewItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }

        //session
        HttpSession session = request.getSession();
        
        //Integer productid = Integer.parseInt(request.getParameter("productid"));
        String productname = request.getParameter("productname");
        String brand = request.getParameter("brand");
        Double price = Double.parseDouble(request.getParameter("price"));
        Integer stock = Integer.parseInt(request.getParameter("stock"));
        String description = request.getParameter("description");

//        boolean availability;
//        if (stock > 0) {
//            availability = true;
//        }
//        else {
//            availability = false;
//        }
        //Boolean availability = Boolean.parseBoolean(request.getParameter("availability"));
        
        
        
        //database
        
        //DBManager manager = (DBManager) session.getAttribute("manager");
        
//        session.setAttribute("added", null);
//        session.setAttribute("fetchMessage", null);
    
    try {
        //int productid = manager.fetchProductid(productname);
        //Product product = new Product(productid, productname, brand, price, stock, description);
        if (productname != null) {
            manager.addNewItem(productname, brand, price, stock, description);
//            int productid = manager.fetchProductid(productname);
//            Product product = new Product(productid, productname, brand, price, stock, description);
//            session.setAttribute("product", product);
            session.setAttribute("added", "Item has been added to Inventory");

            request.getRequestDispatcher("addNewItem.jsp").include(request, response);
            //System.out.println("Back to Inventory Menu");
            response.sendRedirect("addNewItem.jsp");
        } else {
            session.setAttribute("added", "Item has NOT been added to Inventory");
            request.getRequestDispatcher("addNewItem.jsp").include(request, response);
        }
    
    } catch (SQLException ex){
        Logger.getLogger(AddNewItemServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
    
  }
}

