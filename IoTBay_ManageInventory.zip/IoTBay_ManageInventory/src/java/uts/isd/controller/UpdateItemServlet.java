package uts.isd.controller;

import uts.isd.model.dao.DBManager;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import uts.isd.model.*;
import uts.isd.model.dao.DBConnector;

public class UpdateItemServlet extends HttpServlet {
    
    private DBManager manager;
    private DBConnector Connector;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try
        {
            Connector = new DBConnector();
        }catch (ClassNotFoundException | SQLException ex){
            java.util.logging.Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        try
        {       
            manager = new DBManager(Connector.openConnection());  
        }catch (SQLException ex){
            java.util.logging.Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        //session
        HttpSession session = request.getSession();
        String oldproductname = request.getParameter("oldproductname");
        //Integer productid = Integer.parseInt(request.getParameter("productid"));
        String productname = request.getParameter("productname");
        String brand = request.getParameter("brand");
        Double price = Double.parseDouble(request.getParameter("price"));
        Integer stock = Integer.parseInt(request.getParameter("stock"));
        String description = request.getParameter("description");
        String oldProductname = request.getParameter("oldProductname");
        
//        //database
//        DBManager manager = (DBManager) session.getAttribute("manager");
        //Product product = new Product(productid, productname, brand, price, stock, description);
        
        //database
        session.setAttribute("product", null);
        session.setAttribute("updated", null);
        
        //String oldProductname = (String) request.getAttribute("oldProductname");
        
        //int productid = getProductid()
        //productname != null || brand != null || price != null || stock != null || description != null
        
        try{
            Boolean exists = manager.checkItem(oldproductname);
            if (exists) {
                manager.updateItem(manager.fetchProductid(oldproductname), productname, brand, price, stock, description);
                //Product product = manager.fetchItem(oldProductname);
//                Product product = manager.fetchItem(productname);
//                session.setAttribute("product", product);
                session.setAttribute("updated", "Item has now been updated");

                request.getRequestDispatcher("updateItem.jsp").include(request, response);
                //System.out.println("Back to Inventory Menu");
                response.sendRedirect("updateItem.jsp");
                //response.sendRedirect("searchResult.jsp");
            }
            else {
                session.setAttribute("updated", "Item has not been updated");
                request.getRequestDispatcher("updateItem.jsp").include(request, response);
                response.sendRedirect("updateItem.jsp");
            }
//            if (productname != null || brand != null || price != null || stock != null || description != null) {    
//                if (productname != null) {
//                    manager.updateItemName(productname);
//                }
//                if (brand != null) {
//                    manager.updateItemBrand(brand);
//                }
//                if (price != null) {
//                    manager.updateItemPrice(price);
//                }
//                if (stock != null) {
//                    manager.updateItemStock(stock);
//                }
//                if (description != null) {
//                    manager.updateItemDescription(description);
//                }
//
//                Product product = manager.fetchItem(productname);
//                session.setAttribute("product", product);
//                session.setAttribute("updated", "Item has now been updated");
//                request.getRequestDispatcher("updateItem.jsp").include(request, response);
//                response.sendRedirect("searchResult.jsp");
//            }
//            else {
//                session.setAttribute("updated", "Item has not been updated");
//                request.getRequestDispatcher("updateItem.jsp").include(request, response);
//                response.sendRedirect("updateItem.jsp");
//            }   
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode() + " and " + ex.getMessage());
        }
        //request.getRequestDispatcher("manageInventory.jsp").include(request, response);
    }
}