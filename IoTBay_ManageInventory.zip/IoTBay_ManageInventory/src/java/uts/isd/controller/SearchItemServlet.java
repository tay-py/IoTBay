/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import uts.isd.model.dao.DBManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import uts.isd.model.*;
import uts.isd.model.dao.DBConnector;

/**
 *
 * @author rebeccagalletta
 */
public class SearchItemServlet extends HttpServlet {
    
    private DBManager manager;
    private DBConnector Connector;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        try
        {
            Connector = new DBConnector();
        }catch (ClassNotFoundException | SQLException ex){
            java.util.logging.Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        try
        {       
            manager = new DBManager(Connector.openConnection());  
        }catch (SQLException ex){
            java.util.logging.Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        //session
        HttpSession session = request.getSession();
        
        //database
        //DBManager manager = (DBManager) session.getAttribute("manager");
        //Product product = null;
        session.setAttribute("product", null);
        session.setAttribute("found", null);
        
        String productname = request.getParameter("productname");
        
        try {
            boolean check = manager.checkItem(productname);
            if (check) {
                Product product = manager.fetchItem(productname);
                session.setAttribute("product", product);
//                int productid = manager.fetchProductid(productname);
//                session.setAttribute("productid", productid);
                //manager.fetchItem(productname);
                
                
                
                request.getRequestDispatcher("searchItem.jsp").include(request, response);
                //System.out.println("Back to Inventory Menu");
                session.setAttribute("found", "Item has been found in the Inventory");
                response.sendRedirect("searchResult.jsp");
                
//                request.setAttribute("oldProductname", productname);
//                RequestDispatcher rd = request.getRequestDispatcher("UpdateItemServlet");
//                rd.forward(request, response);
                
//                RequestDispatcher rd = request.getRequestDispatcher("UpdateItemServlet");
//                rd.forward(request, response);
            } 
            else {
                session.setAttribute("found", "Item does NOT exist in the Inventory");
                request.getRequestDispatcher("searchItem.jsp").include(request, response);
                response.sendRedirect("searchItem.jsp");
            }
                            
        } catch (SQLException ex){
            Logger.getLogger(SearchItemServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
