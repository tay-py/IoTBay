/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.controller;

import uts.isd.model.dao.DBManager;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import uts.isd.model.*;
import uts.isd.model.dao.DBConnector;

public class DeleteItemServlet extends HttpServlet {
    
    private DBManager manager;
    private DBConnector Connector;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        try
        {
            Connector = new DBConnector();
        }catch (ClassNotFoundException | SQLException ex){
            java.util.logging.Logger.getLogger(AddNewItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        try
        {       
            manager = new DBManager(Connector.openConnection());  
        }catch (SQLException ex){
            java.util.logging.Logger.getLogger(AddNewItemServlet.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        //session
        HttpSession session = request.getSession();
        String oldproductname = request.getParameter("oldproductname");
        
        //database
        //DBManager manager = (DBManager) session.getAttribute("manager");
        //Product product = null;
        
        try {
            Boolean exists = manager.checkItem(oldproductname);
            //Product product = manager.fetchItem(oldproductname);
            //session.setAttribute("product", product);
            if (exists) {
                manager.deleteItem(oldproductname);
                session.setAttribute("deleted", "Product has been deleted.");
                request.getRequestDispatcher("deleteItem.jsp").include(request, response);
                response.sendRedirect("deleteItem.jsp");
            }
            else {
                session.setAttribute("deleted", "Product has NOT been deleted.");
                request.getRequestDispatcher("deleteItem.jsp").include(request, response);
                //response.sendRedirect("deleteItem.jsp");
            }
            //System.out.println("Redirect to Search Item Page");
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode() + " and " + ex.getMessage());
        }
        //request.getRequestDispatcher("searchItem.jsp").include(request, response);
    }
}
