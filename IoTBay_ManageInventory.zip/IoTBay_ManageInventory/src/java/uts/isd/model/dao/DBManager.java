/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.model.dao;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;
import uts.isd.model.*;

/**
 *
 * @author rebeccagalletta
 */
public class DBManager {
    
    private Statement st;

    public DBManager(Connection conn) throws SQLException {       
       st = conn.createStatement();   
    }
    
    //public Product findProduct()
    
    public void addNewItem(String productname, String brand, double price, int stock, String description) throws SQLException {
        
        //String getid = "SELECT ROW_NUMBER() OVER (ORDER BY PRODUCTNAME)";
        //ResultSet rs = st.executeQuery(getid);
        
        //Integer productid = Integer.parseInt(rs.getObject(1));
        int temp = 0;
        String query = "INSERT INTO APP.PRODUCT VALUES ("+temp+",'"+productname+"', '"+brand+"', "+price+", "+stock+", '"+description+"')";
        st.executeUpdate(query);
        
        //String getlastid = "SELECT PRODUCTID FROM APP.PRODUCT";

        String getid = "UPDATE APP.PRODUCT SET PRODUCTID = (SELECT MAX(PRODUCTID) FROM APP.PRODUCT) + 1 WHERE PRODUCTID = 0";
        st.executeUpdate(getid);
    }
    
    public ResultSet readInventory() throws SQLException {
        return st.getResultSet();
    }

    public void updateItem(int productid, String productname, String brand, double price, int stock, String description) throws SQLException {        
        String query = "UPDATE APP.PRODUCT SET PRODUCTNAME = ('"+productname+"'), BRAND = ('"+brand+"'), PRICE = ("+price+"), STOCK = ("+stock+"), DESCRIPTION = ('"+description+"') WHERE PRODUCTID = ("+productid+")";
        st.executeUpdate(query);
        
    }
    
//    public void updateItemName(String productname) throws SQLException {
//        String query = "UPDATE APP.PRODUCT SET (PRODUCTNAME) = ('"+productname+"')";
//        st.executeUpdate(query);
//    }
//    public void updateItemBrand(String brand) throws SQLException {
//        String query = "UPDATE APP.PRODUCT SET (BRAND) = ('"+brand+"')";
//        st.executeUpdate(query);
//    }
//    public void updateItemPrice(double price) throws SQLException {
//        String query = "UPDATE APP.PRODUCT SET (PRICE) = ("+price+")";
//        st.executeUpdate(query);
//    }
//    public void updateItemStock(int stock) throws SQLException {
//        String query = "UPDATE APP.PRODUCT SET (STOCK) = ("+stock+")";
//        st.executeUpdate(query);
//    }
//    public void updateItemDescription(String description) throws SQLException {
//        String query = "UPDATE APP.PRODUCT SET (DESCRIPTION) = ('"+description+"')";
//        st.executeUpdate(query);
//    }
    
    public void deleteItem(String productname) throws SQLException {
        String query = "DELETE FROM APP.PRODUCT WHERE (PRODUCTNAME) = ('"+productname+"')";
        st.executeUpdate(query);
    }
    
    public boolean checkItem(String productname) throws SQLException {
        String query = "SELECT * FROM APP.PRODUCT WHERE (PRODUCTNAME) = '"+productname+"'";
        ResultSet rs = st.executeQuery(query);
        
        while (rs.next()) {
            String item_productname = rs.getString(2);
            
            if (item_productname.equals(productname)) {
                return true;
            }
        }
        return false;
    }
    
    public int fetchProductid(String productname) throws SQLException {
        String query = "SELECT PRODUCTID FROM APP.PRODUCT WHERE PRODUCTNAME = '"+productname+"'";
        ResultSet rs = st.executeQuery(query);
        int productid = 0;
        
        while (rs.next()) {
            productid = rs.getInt(1);
        }
        //return null;
        return productid;
    }
    
    public Product fetchItem(String productname) throws SQLException {
        String query = "SELECT * FROM APP.PRODUCT WHERE (PRODUCTNAME) = '"+productname+"'";
        ResultSet rs = st.executeQuery(query);
        
        while (rs.next()) {
            String item_productname = rs.getString(2);
            if (item_productname.equals(productname)) {
                int item_productid = rs.getInt(1);
                String item_brand = rs.getString(3);
                double item_price = rs.getDouble(4);
                int item_stock = rs.getInt(5);
                String item_description = rs.getString(6);
                return new Product(item_productid, item_productname, item_brand, item_price, item_stock, item_description);
            }
        }
        return null;
    }
    
    public ArrayList<Product> showInventory() throws SQLException {
        String query = "SELECT * FROM APP.PRODUCT ORDER BY PRODUCTID";
        ResultSet rs = st.executeQuery(query);
        ArrayList<Product> inventory = new ArrayList();
        
        while (rs.next()) {
            int item_productid = rs.getInt(1);
            String item_productname = rs.getString(2);
            String item_brand = rs.getString(3);
            double item_price = rs.getDouble(4);
            int item_stock = rs.getInt(5);
            String item_description = rs.getString(6);
            
            inventory.add(new Product(item_productid, item_productname, item_brand, item_price, item_stock, item_description));
        }
        
        return inventory;
    }
    
}
