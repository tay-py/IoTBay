package Controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import IOTBayDB.User;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DBConnector;
import model.DBManager;
import java.sql.Timestamp;
import java.util.HashSet;

/**
 *
 * @author Bailey
 */
//@WebServlet("/loginCheck")
public class checkLogin extends HttpServlet {
private DBConnector connector; 
private Connection conn;
private DBManager db;


public checkLogin() {}
private static final User sessionU = new User(); 



    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException {
       
          
            
       try {
                String email= request.getParameter("loginemail");
                String password= request.getParameter("loginpass");
                connector = new DBConnector();
                conn = connector.openConnection();  
                db = new DBManager(conn); 
                boolean c = db.checkUser(email, password);
                boolean b = db.checkStaff(email, password);
           if(c == true) {
            response.sendRedirect("Welcome.jsp");
            loginTime(email,password);
           User user =  db.setUser(email, password); 
           String username = user.getUsername();
           String fname = user.getFirstName(); 
           String lName = user.getLastName(); 
           String address = user.getAddress(); 
           String id = user.getUserId(); 
           sessionU.setUsername(username);
           sessionU.setFirstName(fname);
           sessionU.setLastName(lName);
           sessionU.setAddress(address);
           sessionU.setUserId(id);
           sessionU.setEmail(email); 
           sessionU.setPassword(password);
               
               
           } else 
            if(b == true)
                 response.sendRedirect("Welcome.jsp");
            else 
                response.sendRedirect("Register.jsp");
                
             
               
      } catch (SQLException ex) {
        Logger.getLogger(userController.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(userController.class.getName()).log(Level.SEVERE, null, ex);
    }
       
       //System.out.println(password);
       //System.out.println(email);
      
}
    private static final Timestampbean instance = new Timestampbean();
    
       
      private void loginTime(String email, String password) throws SQLException {
       String userID = db.findUserID(email,password);
       long time = System.currentTimeMillis();
       Timestamp timestamp = new Timestamp(time); 
       db.addLog(userID, timestamp);
       //Timestampbean beaner = new Timestampbean(); 
       instance.setTime(timestamp); 
       
       
       } 
  public static Timestampbean getInstance() {
      return instance; 
  }
  
  public static User getInstanceUser() { 
      return sessionU;
  }
      
  
            //System.out.println(password);
            //System.out.println(email);
             
    }
              

    
  


