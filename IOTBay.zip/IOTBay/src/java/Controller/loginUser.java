/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;


                                                 
/**
 *
 * @author Bailey
 */
public class loginUser {
private String userEmail ;
private String userPassword;

    public loginUser(String userEmail, String userPassword) {
        this.userEmail = userEmail;
        this.userPassword = userPassword; }
    

public loginUser() {} 

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

}