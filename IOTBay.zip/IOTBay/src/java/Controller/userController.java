package Controller;
import java.sql.*;
import java.util.logging.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DBConnector;
import model.DBManager;

 

public class userController  extends HttpServlet {
     //private static final long serialVersionUID = 1L;
private DBConnector connector; 
private Connection conn;
private DBManager db;
 /*public void init() {
 (new userController()).doGet();
 } */
/*public void init(){
         try {
             db = new DBManager(conn);
         } catch (SQLException ex) {
             Logger.getLogger(userController.class.getName()).log(Level.SEVERE, null, ex);
         }
} */
public userController(){
}

@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
             throws ServletException, IOException { 
            
            try {
                connector = new DBConnector();
                conn = connector.openConnection();  
             db = new DBManager(conn);
             String regiEmail = request.getParameter("email");
             boolean emailFalse = db.checkEmail(regiEmail); 
             if (emailFalse != true){
                insert(request,response);
                response.sendRedirect("index.html"); }
             else {
                 response.sendRedirect("Failregister.jsp");
             }
        //db.addUser(regiEmail, regiEmail, regiFirstName, regiLastName, regiPassword, regiUsername, regiAddress);
        //connector.closeConnection();
    } catch (SQLException ex) {
        Logger.getLogger(userController.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(userController.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
    
    
   private void insert(HttpServletRequest request, HttpServletResponse response) 
       throws SQLException, IOException {
        String regiEmail = request.getParameter("email");
        String regiFirstName = request.getParameter("firstName");
        String regiLastName = request.getParameter("lastName");
        String regiPassword = request.getParameter("password");
        String regiUsername= request.getParameter("username");
        String regiAddress= request.getParameter("address");
        String userID = db.userIdinc();
        if (userID == null)
         userID = "1"; 

db.addUser(regiUsername, regiFirstName, regiLastName, regiAddress, regiEmail, regiPassword, userID);


connector.closeConnection();
   
   
   }  
}
               



