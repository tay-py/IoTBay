package model;
import Controller.loginUser;
import java.sql.*;
import java.util.ArrayList;
import IOTBayDB.User;

/* 
* DBManager is the primary DAO class to interact with the database. 
* Complete the existing methods of this classes to perform CRUD operations with the db.
*/

public class DBManager {

private final Statement st;
   
public DBManager(Connection conn) throws SQLException {     
  st = conn.createStatement();   
}
/*
createUser
readUser
updateUser
deleteUser 
*/   

/*
//delete a user from the database   
public void deleteUser(String email) throws SQLException{       
   //code for delete-operation   
   st.executeUpdate("DELETE FROM USERDB.USERDB WHERE EMAIL='" + email + "'");
}
   public ArrayList<User> fetchUser()throws SQLException { 
       String fetch = "select * from USERDB"; 
       ResultSet rs = st.executeQuery(fetch);
       ArrayList<User> temp = new ArrayList(); 
       
       while (rs.next()) { 
           String name = rs.getString(1);
           String email = rs.getString(2);
           String password = rs.getString(3);
           String dob = rs.getString(4);
           temp.add(new User(name,email,password,dob));
       }
       return temp;
       }
   */
  
        

// ======================Everything between this is updateUser======================
public void addLogout(String userID, Timestamp logoutTime, Timestamp loginTime) throws SQLException {
    //String query = ("UPDATE BAILEY.ACCESSLOGDB SET LOGOUTTIME='" + logoutTime + "' WHERE USERID='" + userID + "' AND LOGINTIME='" +loginTime+"'"); 
    String query = ("UPDATE BAILEY.ACCESSLOGDB SET LOGOUTTIME='" + logoutTime + "' WHERE USERID='" + userID +"' AND LOGINTIME='"+ loginTime + "'"); 
    //String query = ("UPDATE BAILEY.ACCESSLOGDB SET LOGOUTTIME='" + logoutTime + "' WHERE LOGINTIME='" + loginTime +"'"); 
    st.executeUpdate(query); 
}

public void updateEmail(String email, String userID) throws SQLException{
String query = ("UPDATE BAILEY.USERDB SET USEREMAIL='" + email + "' WHERE USERID='"+ userID + "'"); 
    st.executeUpdate(query); 
}

public void updateFName(String fName, String userID)throws SQLException {
String query = ("UPDATE BAILEY.USERDB SET USERFNAME='" + fName + "' WHERE USERID='"+ userID + "'"); 
    st.executeUpdate(query); 
}
public void updateLName(String lName, String userID)throws SQLException {
String query = ("UPDATE BAILEY.USERDB SET USERLNAME='" + lName + "' WHERE USERID='"+ userID + "'"); 
    st.executeUpdate(query); 
}
public void updatePassword(String password, String userID)throws SQLException{
String query = ("UPDATE BAILEY.USERDB SET USERPASSWORD='" + password + "' WHERE USERID='"+ userID + "'"); 
    st.executeUpdate(query); 
}
public void updateUsername(String username, String userID)throws SQLException {
String query = ("UPDATE BAILEY.USERDB SET USERUSERNAME='" + username + "' WHERE USERID='"+ userID + "'"); 
    st.executeUpdate(query); 
}
public void updateAddress(String address, String userID)throws SQLException {
    String query = ("UPDATE BAILEY.USERDB SET USEREMAIL='" + address + "' WHERE USERID='"+ userID + "'"); 
    st.executeUpdate(query); 
}

// =======================Everything above this is updateUser=======================


// ======================Everything below this is deleteUser======================

public void deleteUser(String Id) throws SQLException{       
   //code for delete-operation   
   st.executeUpdate("DELETE FROM BAILEY.USERDB WHERE USERID='" + Id + "'");
}

// =======================Everything above this is deleteUser=======================


// ======================Everything between this is createUser======================
public void addLog(String userID, Timestamp logoutTime) throws SQLException
{
String query = "INSERT INTO BAILEY.ACCESSLOGDB (USERID, LOGINTIME) VALUES ('"+userID+"', '"+logoutTime+"')"; 
st.executeUpdate(query); 
}

public void addUser( String userUsername, String userFName, String userLName, String userAddress, String userEmail, String userPassword, String userID) throws SQLException { 
    //code for add-operation       
 String query = "INSERT INTO BAILEY.USERDB (USERUSERNAME, USERFNAME, USERLNAME, USERADDRESS, USEREMAIL, USERPASSWORD, USERID) VALUES ('"+userUsername+"', '"+userFName+"','"+userLName+"', '"+userAddress+"', '"+userEmail+"', '"+ userPassword+"', '"+userID+"')"; 
st.executeUpdate(query); 
}

// =======================Everything above this is createUser=======================


// ======================Everything between this is readUser======================
//Basically is just stuff that isn't directly CRUD
public boolean checkUser(String email, String password) throws SQLException { 
   loginUser b = new loginUser(); 
   boolean c = false; 
       String fetch = "select * from BAILEY.USERDB where USEREMAIL= '" + email + "' and USERPASSWORD= '" + password + "'"; 
       ResultSet rs = st.executeQuery(fetch);
       while (rs.next()){ 
          //c.setUserEmail(rs.getString(1));
           //c.setUserPassword(rs.getString(2)); 
           String emailCheck= rs.getString(1);
           String passwordCheck = rs.getString(2); 
           if(emailCheck != null && passwordCheck != null) {
               c = true;
               break; 
           }
   }
         return c; 
 }

public boolean checkEmail(String email) throws SQLException {
     boolean c = false; 
      String fetch = "select * from BAILEY.USERDB where USEREMAIL= '" + email + "'"; 
      ResultSet rs = st.executeQuery(fetch);
      while (rs.next()){ 
          String emailCheck = rs.getString(1); 
          if (emailCheck != null) {
              c = true; 
              break; 
          }
      }
      return c; 
 }
  public User setUser(String email, String password) throws SQLException {
      User user = null;
      String fetch = "select * from BAILEY.USERDB where USEREMAIL= '" + email + "' and USERPASSWORD= '" + password + "'"; 
      ResultSet rs = st.executeQuery(fetch);
       while (rs.next()){ 
           String userEmail = rs.getString(5);
           String userFName = rs.getString (2); 
           String userLName = rs.getString(3);
           String userPass = rs.getString(6);
           String userAddress = rs.getString(4); 
           String userUsername = rs.getString(1); 
           String userID = rs.getString(7); 
           User temp = new User(userEmail, userFName, userLName, userPass, userAddress, userUsername, userID); 
           user = temp; 
       }
       return user; 
 }
  
  public String findUserID(String email, String password) throws SQLException {
      String userID = null; 
       String fetch = "select * from BAILEY.USERDB where USEREMAIL= '" + email + "' and USERPASSWORD= '" + password + "'"; 
       ResultSet rs = st.executeQuery(fetch);
       while (rs.next()){ 
          //c.setUserEmail(rs.getString(1));
           //c.setUserPassword(rs.getString(2)); 
           userID= rs.getString(7);
           
     
 }
       return userID; 
 }
  
  public boolean checkStaff(String email, String password) throws SQLException { 
   loginUser b = new loginUser(); 
   boolean c = false; 
       String fetch = "select * from BAILEY.STAFFID where USEREMAIL= '" + email + "' and USERPASSWORD= '" + password + "'"; 
       ResultSet rs = st.executeQuery(fetch);
       while (rs.next()){ 
          //c.setUserEmail(rs.getString(1));
           //c.setUserPassword(rs.getString(2)); 
           String emailCheck= rs.getString(1);
           String passwordCheck = rs.getString(2); 
           if(emailCheck != null && passwordCheck != null) {
               c = true;
               break; 
           }
   }
         return c; 
 }
  public boolean findPassword (String email) throws SQLException{
String fetch = "select  * from BAILEY.USERDB where USEREMAIL = '" + email  + "'";  
  ResultSet rs = st.executeQuery(fetch);
 String passwordCheck = rs.getString(7);
 if (passwordCheck != null) {
     return true; }
 else {
     return false; 
 } 
 }
   
  
  public User findUser(String userID, String userUsername, String userFName, String userLName, String userAddress, String userEmail, String userPassword) throws SQLException {       
  String fetch = "select  * from BAILEY.USERDB where EMAIL = '" + userEmail  + "' and PASSWORD '" + userPassword + "'";  
  ResultSet rs = st.executeQuery(fetch);
  
  while (rs.next()) { 
      String email = rs.getString(6);
      String password = rs.getString(7);
      if (email.equals(userEmail) && password.equals(userPassword)) { 
            String ID = rs.getString(1);
            String username = rs.getString(2);
            String fName = rs.getString(3);
            String lName = rs.getString(4);
            String address = rs.getString(5);
            return new User(ID, username, fName, lName,  address,  email, password);
            
      }
  }
   return null;   
} 
  
  
  public String userIdinc() throws SQLException {
int id = 0;
String ids = null; 
String fetch = "SELECT * FROM BAILEY.USERDB ORDER BY LENGTH(USERID), USERID ASC";
st.executeQuery(fetch);
ResultSet rs = st.executeQuery(fetch);
while (rs.next()) {
String intCheck = rs.getString(7);
id = Integer.parseInt(intCheck);
id = id + 1; 
ids = Integer.toString(id); 
        
}
return ids; 
}
//Basically is just stuff that isn't directly CRUD
// =======================Everything above this is readUser=======================
   

}
